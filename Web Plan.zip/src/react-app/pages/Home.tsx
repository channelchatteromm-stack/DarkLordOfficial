import { useState } from "react";
import { Youtube, Bell, ThumbsUp, Share2, Play, Pause, Flame, Eye, Users, Film, Zap, Target, Gamepad2, Trophy, Mail } from "lucide-react";
import { Button } from "@/react-app/components/ui/button";

const stats = [
  { icon: Film, value: "150+", label: "Shorts" },
  { icon: Users, value: "279+", label: "Subscribers" },
  { icon: Eye, value: "99K+", label: "Views" },
];

export default function HomePage() {
  const [isPlaying, setIsPlaying] = useState(false);

  const toggleMusic = () => {
    setIsPlaying(!isPlaying);
  };

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      {/* Animated background grid */}
      <div className="absolute inset-0 opacity-20">
        <div 
          className="absolute inset-0"
          style={{
            backgroundImage: `
              linear-gradient(rgba(255,50,50,0.1) 1px, transparent 1px),
              linear-gradient(90deg, rgba(255,50,50,0.1) 1px, transparent 1px)
            `,
            backgroundSize: '60px 60px',
          }}
        />
      </div>
      
      {/* Radial glow from center */}
      <div 
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] rounded-full opacity-30 pointer-events-none"
        style={{
          background: 'radial-gradient(circle, hsl(0 85% 55% / 0.4) 0%, transparent 70%)',
        }}
      />

      {/* Content */}
      <div className="relative z-10">
        {/* Channel Banner */}
        <div className="w-full overflow-hidden border-b-2 border-primary/30">
          <img 
            src="https://019c9fba-dce5-73ad-94da-cf9b4a3b06a2.mochausercontent.com/IMG_20260227_211157.jpg" 
            alt="Dark Lord Channel Banner"
            className="w-full h-auto object-cover"
          />
        </div>

        {/* Contact Email */}
        <div className="w-full py-3 bg-card/50 backdrop-blur-sm border-b border-primary/20 flex flex-col items-center gap-2">
          <a 
            href="mailto:darklordofficialbusiness@gmail.com"
            className="flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors"
          >
            <Mail className="w-4 h-4" />
            <span className="text-sm md:text-base">darklordofficialbusiness@gmail.com</span>
          </a>
          <a
            href="mailto:darklordofficialbusiness@gmail.com"
            className="px-4 py-2 bg-primary/20 hover:bg-primary/30 border border-primary/50 rounded-full text-primary text-sm font-semibold transition-all hover:scale-105"
          >
            Chat with me
          </a>
        </div>

        {/* Hero Section */}
        <section className="flex flex-col items-center px-4 py-12 md:py-16">
          {/* Flame icon above title */}
          <div className="mb-4 relative">
            <Flame className="w-12 h-12 text-primary animate-pulse" />
            <div className="absolute inset-0 blur-xl bg-primary/50 rounded-full" />
          </div>
          
          {/* Main Title */}
          <h1 className="font-display text-5xl md:text-7xl lg:text-8xl font-black text-center tracking-wider mb-4">
            <span className="text-glow text-primary">DARK</span>
            <span className="text-foreground ml-4">LORD</span>
          </h1>
          
          {/* Subtitle */}
          <p className="text-xl md:text-2xl text-muted-foreground font-medium tracking-widest uppercase mb-8">
            Mobile Gaming Channel
          </p>
          
          {/* Tagline */}
          <p className="text-lg md:text-xl text-center max-w-2xl text-foreground/80 mb-8 leading-relaxed">
            Hii Gamers! Welcome to Dark Lord FF — your destination for epic mobile gameplay. 
            Let's have fun together!
          </p>
          
          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 mb-10">
            <Button 
              size="lg" 
              className="bg-red-600 hover:bg-red-700 text-white font-bold px-8 py-6 text-lg box-glow transition-all hover:scale-105"
              onClick={() => window.open('https://youtube.com/@mr_dark_lord_yt?si=HmL34-F_oidHtOsz', '_blank')}
            >
              <Youtube className="w-6 h-6 mr-2" />
              Subscribe Now
            </Button>
            <Button 
              size="lg" 
              variant="outline"
              className="border-primary/50 text-primary hover:bg-primary/10 font-bold px-8 py-6 text-lg border-glow transition-all hover:scale-105"
              onClick={() => window.open('https://youtube.com/@mr_dark_lord_yt?si=HmL34-F_oidHtOsz', '_blank')}
            >
              <Bell className="w-6 h-6 mr-2" />
              Turn On Notifications
            </Button>
          </div>
          
          {/* Stats */}
          <div className="grid grid-cols-3 gap-6 md:gap-12 w-full max-w-2xl">
            {stats.map((stat) => (
              <div 
                key={stat.label}
                className="flex flex-col items-center p-4 md:p-6 rounded-xl bg-card/50 border border-primary/20 border-glow backdrop-blur-sm"
              >
                <stat.icon className="w-8 h-8 text-primary mb-2" />
                <span className="font-display text-3xl md:text-4xl font-bold text-foreground">
                  {stat.value}
                </span>
                <span className="text-sm md:text-base text-muted-foreground uppercase tracking-wider">
                  {stat.label}
                </span>
              </div>
            ))}
          </div>
        </section>

        {/* What You Get Section */}
        <section className="py-20 px-4">
          <div className="max-w-5xl mx-auto">
            <h2 className="font-display text-3xl md:text-4xl font-bold text-center mb-4">
              <span className="text-primary text-glow">WHAT</span> YOU GET
            </h2>
            <p className="text-center text-muted-foreground mb-12 text-lg">
              Subscribe and unlock the ultimate gaming experience
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <FeatureCard 
                icon={Zap}
                title="Daily Shorts"
                description="Fresh gaming content uploaded regularly to keep you entertained"
              />
              <FeatureCard 
                icon={Gamepad2}
                title="Epic Gameplay"
                description="Intense Free Fire moments and clutch plays"
              />
              <FeatureCard 
                icon={Target}
                title="Pro Tips"
                description="Learn strategies to level up your game"
              />
              <FeatureCard 
                icon={Trophy}
                title="Best Moments"
                description="Highlights and victory royales compilations"
              />
            </div>
          </div>
        </section>

        {/* About Section */}
        <section className="py-20 px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="font-display text-3xl md:text-4xl font-bold text-center mb-12">
              <span className="text-primary text-glow">ABOUT</span> THE CHANNEL
            </h2>
            
            <div className="bg-card/60 backdrop-blur-sm rounded-2xl p-8 md:p-12 border border-primary/20 border-glow">
              <div className="flex items-start gap-4 mb-6">
                <button 
                  onClick={toggleMusic}
                  className="w-16 h-16 rounded-full bg-gradient-to-br from-primary to-red-800 flex items-center justify-center flex-shrink-0 hover:scale-110 transition-transform duration-300 cursor-pointer shadow-lg shadow-primary/30 hover:shadow-primary/50"
                  aria-label={isPlaying ? "Pause music" : "Play music"}
                >
                  {isPlaying ? (
                    <Pause className="w-8 h-8 text-white" />
                  ) : (
                    <Play className="w-8 h-8 text-white ml-1" />
                  )}
                </button>
                <div>
                  <h3 className="font-display text-2xl font-bold text-foreground mb-1">Dark Lord FF</h3>
                  <p className="text-muted-foreground">Mobile Gaming Content Creator</p>
                  {isPlaying && (
                    <p className="text-primary text-sm mt-1 animate-pulse">♪ Now Playing: Matushka UltraFunk</p>
                  )}
                </div>
              </div>
              
              {/* Hidden YouTube Audio Player */}
              {isPlaying && (
                <iframe
                  className="hidden"
                  src="https://www.youtube.com/embed/CsrsR_sC2jE?autoplay=1&loop=1&playlist=CsrsR_sC2jE"
                  allow="autoplay"
                  title="Matushka UltraFunk"
                />
              )}
              
              <p className="text-lg text-foreground/90 leading-relaxed mb-6">
                I am Dark Lord. This is a gaming channel where the main goal is to <span className="text-primary font-semibold">entertain you all</span> — my awesome audience! 
                Watch my mobile gameplay, enjoy the action, and join the gaming community.
              </p>
              
              <div className="flex flex-wrap gap-3">
                <span className="px-4 py-2 rounded-full bg-primary/20 text-primary border border-primary/30 text-sm font-medium">
                  🎮 Mobile Gaming
                </span>
                <span className="px-4 py-2 rounded-full bg-primary/20 text-primary border border-primary/30 text-sm font-medium">
                  🔥 Free Fire
                </span>
                <span className="px-4 py-2 rounded-full bg-primary/20 text-primary border border-primary/30 text-sm font-medium">
                  📱 Shorts Content
                </span>
                <span className="px-4 py-2 rounded-full bg-primary/20 text-primary border border-primary/30 text-sm font-medium">
                  🎯 Gameplay
                </span>
              </div>
            </div>
          </div>
        </section>

        {/* Featured Video Section */}
        <section className="py-20 px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="font-display text-3xl md:text-4xl font-bold text-center mb-12">
              <span className="text-primary text-glow">FEATURED</span> VIDEOS
            </h2>
            
            <div className="flex flex-col md:flex-row justify-center gap-6 md:gap-8">
              <div className="relative w-full max-w-[320px] mx-auto aspect-[9/16] rounded-2xl overflow-hidden border-2 border-primary/30 box-glow">
                <iframe
                  src="https://www.youtube.com/embed/LJVLw7r5zBQ"
                  title="Dark Lord Featured Short 1"
                  className="absolute inset-0 w-full h-full"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                />
              </div>
              <div className="relative w-full max-w-[320px] mx-auto aspect-[9/16] rounded-2xl overflow-hidden border-2 border-primary/30 box-glow">
                <iframe
                  src="https://www.youtube.com/embed/IcjJCSMPX4A"
                  title="Dark Lord Featured Short 2"
                  className="absolute inset-0 w-full h-full"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                />
              </div>
            </div>
            
            <p className="text-center text-muted-foreground mt-6">
              Check out more shorts on the channel!
            </p>
          </div>
        </section>

        {/* Call to Action Section */}
        <section className="py-20 px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="font-display text-3xl md:text-4xl font-bold mb-6">
              JOIN THE <span className="text-primary text-glow">DARK LORD</span> ARMY
            </h2>
            
            <p className="text-lg text-muted-foreground mb-10">
              Don't miss any epic gaming moments! Like, share, and subscribe to stay updated.
            </p>
            
            <div className="flex flex-col sm:flex-row justify-center gap-4 mb-12">
              <ActionCard 
                icon={ThumbsUp}
                title="Like"
                description="Show some love"
              />
              <ActionCard 
                icon={Share2}
                title="Share"
                description="Spread the word"
              />
              <ActionCard 
                icon={Bell}
                title="Subscribe"
                description="Join the family"
                onClick={() => window.open('https://youtube.com/@mr_dark_lord_yt?si=HmL34-F_oidHtOsz', '_blank')}
              />
            </div>
            
            <Button 
              size="lg" 
              className="bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white font-bold px-12 py-7 text-xl box-glow transition-all hover:scale-105"
              onClick={() => window.open('https://youtube.com/@mr_dark_lord_yt?si=HmL34-F_oidHtOsz', '_blank')}
            >
              <Youtube className="w-7 h-7 mr-3" />
              Watch on YouTube
            </Button>
          </div>
        </section>

        {/* Footer */}
        <footer className="py-8 px-4 border-t border-border/50">
          <div className="max-w-4xl mx-auto text-center">
            <p className="font-display text-xl font-bold text-primary mb-2">DARK LORD</p>
            <p className="text-muted-foreground text-sm mb-2">
              Have fun gaming!
            </p>
            <p className="text-muted-foreground/70 text-xs">
              © {new Date().getFullYear()} Dark Lord. All rights reserved.
            </p>
          </div>
        </footer>
      </div>
    </div>
  );
}

function ActionCard({ icon: Icon, title, description, onClick }: { icon: any; title: string; description: string; onClick?: () => void }) {
  return (
    <div className="flex-1 p-6 rounded-xl bg-card/50 border border-primary/20 hover:border-primary/50 transition-all hover:scale-105 cursor-pointer group" onClick={onClick}>
      <Icon className="w-10 h-10 text-primary mx-auto mb-3 group-hover:scale-110 transition-transform" />
      <h3 className="font-display font-bold text-lg text-foreground">{title}</h3>
      <p className="text-sm text-muted-foreground">{description}</p>
    </div>
  );
}

function FeatureCard({ icon: Icon, title, description }: { icon: any; title: string; description: string }) {
  return (
    <div className="group relative p-6 rounded-2xl bg-gradient-to-br from-card/80 to-card/40 border border-primary/20 hover:border-primary/50 transition-all duration-300 hover:scale-105 backdrop-blur-sm overflow-hidden">
      {/* Glow effect on hover */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
      
      <div className="relative z-10">
        <div className="w-14 h-14 rounded-xl bg-primary/20 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
          <Icon className="w-7 h-7 text-primary" />
        </div>
        <h3 className="font-display font-bold text-xl text-foreground mb-2">{title}</h3>
        <p className="text-sm text-muted-foreground leading-relaxed">{description}</p>
      </div>
    </div>
  );
}
